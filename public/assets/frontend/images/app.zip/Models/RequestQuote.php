<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class RequestQuote extends Model
{
    protected $fillable = [
        'name',
        'email',
        'mobile_no',
        'country',
        'product',
        'query',
        'file_name',
    ];
}
